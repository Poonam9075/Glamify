package com.glamify.repository;

import com.glamify.entity.BookedService;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookedServiceRepository extends JpaRepository<BookedService, Long> {
}
