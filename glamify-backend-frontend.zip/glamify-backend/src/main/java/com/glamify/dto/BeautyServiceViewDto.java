package com.glamify.dto;

import lombok.Data;

@Data
public class BeautyServiceViewDto {

    private String serviceName;
    private int estimatedTime;
}
