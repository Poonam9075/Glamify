package com.glamify.dto;

import lombok.Data;

@Data
public class CustomerRegisterRequest extends UserRegisterRequest {
    // future customer-only fields
}
