package com.glamify.entity;

import jakarta.persistence.Entity;

@Entity
public class Admin extends User {
	
}
