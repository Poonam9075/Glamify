package com.glamify.entity;


public enum Role {
    ADMIN,
    CUSTOMER,
    PROFESSIONAL
}
