package com.glamify.entity;

public enum PaymentStatus {
	INITIATED,
    SUCCESS,
    FAILED,
    REFUNDED, PENDING
}
