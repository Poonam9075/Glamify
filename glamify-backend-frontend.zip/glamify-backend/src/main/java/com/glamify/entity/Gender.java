package com.glamify.entity;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
