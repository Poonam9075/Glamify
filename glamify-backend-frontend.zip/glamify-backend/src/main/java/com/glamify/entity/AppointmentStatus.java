package com.glamify.entity;

public enum AppointmentStatus {
	REQUESTED,
	//CREATED,
	CONFIRMED,
    PAYMENT_PENDING,
    ACCEPTED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}
