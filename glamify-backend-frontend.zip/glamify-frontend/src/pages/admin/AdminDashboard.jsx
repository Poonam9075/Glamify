import { useEffect, useState } from "react";
import {
  getPendingProfessionals,
  approveProfessional,
  getAllUsers,
  getAllBeautyServices,
  toggleUserStatus,
  addBeautyService,
  updateBeautyService,
  getAllAppointments
} from "../../api/adminApi";

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "professionals", label: "Professionals" },
  { key: "services", label: "Services" },
  { key: "bookings", label: "Bookings" },
  { key: "users", label: "Users" }
];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [stats, setStats] = useState(null);
  const [loadingStats, setLoadingStats] = useState(true);

  return (
    <div style={{ padding: 24, maxWidth: 1100, margin: "0 auto" }}>
      <h2 style={{ marginBottom: 16 }}>Admin Dashboard</h2>

      <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            className="category-btn"
            onClick={() => setActiveTab(t.key)}
            style={{
              background: activeTab === t.key ? "var(--primary)" : "#fff",
              color: activeTab === t.key ? "#fff" : "#000",
              borderColor: activeTab === t.key ? "var(--primary)" : "#ddd"
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {activeTab === "overview" && <OverviewTab setActiveTab={setActiveTab} />}
      {activeTab === "professionals" && <ProfessionalsTab />}
      {activeTab === "services" && <ServicesTab />}
      {activeTab === "bookings" && <BookingsTab />}
      {activeTab === "users" && <UsersTab />}
    </div>
  );
}

/* ================= SERVICES TAB ================= */

function ServicesTab() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingService, setEditingService] = useState(null);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    const data = await getAllBeautyServices();
    setServices(data);
    setLoading(false);
  };

  const openAdd = () => {
    setEditingService(null);
    setShowModal(true);
  };

  const openEdit = (service) => {
    setEditingService(service);
    setShowModal(true);
  };

  const handleSave = async (payload) => {
    if (editingService) {
      await updateBeautyService(editingService.id, payload);
    } else {
      await addBeautyService(payload);
    }
    setShowModal(false);
    loadServices();
  };

  if (loading) return <p>Loading services...</p>;

  return (
    <div className="card" style={{ padding: 20 }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginBottom: 12
        }}
      >
        <h4>Beauty Services</h4>
        <button className="add-service-btn" onClick={openAdd}>
          <b>+  Add Service</b>
        </button>
      </div>

      <div style={{ maxHeight: 420, overflowY: "auto" }}>
        <table style={{ width: "100%", fontSize: 14 }}>
          <thead style={{ position: "sticky", top: 0, background: "#fff" }}>
            <tr>
              {["Name", "Category", "Price", "Duration", "Discount", "Status", ""].map((h) => (
                <th key={h} style={th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {services.map((s, i) => (
              <tr key={s.id} style={{ background: i % 2 ? "#fafafa" : "#fff" }}>
                <td style={td}>{s.name}</td>
                <td style={td}>{s.category}</td>
                <td style={td}>₹{s.price}</td>
                <td style={td}>{s.duration} min</td>
                <td style={td}>{s.discount}%</td>
                <td style={td}>{s.active ? "Active" : "Inactive"}</td>
                <td style={td}>
                  <button
                    className="btn"
                    style={{ padding: "6px 14px", borderRadius: 999 }}
                    onClick={() => openEdit(s)}
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <ServiceModal
          initial={editingService}
          onClose={() => setShowModal(false)}
          onSave={handleSave}
        />
      )}
    </div>
  );
}

/* ================= SERVICE MODAL ================= */

function ServiceModal({ initial, onClose, onSave }) {
  const [form, setForm] = useState({
    name: initial?.name || "",
    category: initial?.category || "",
    price: initial?.price || "",
    duration: initial?.duration || "",
    discount: initial?.discount || 0
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const submit = () => {
    onSave({
      name: form.name,
      category: form.category,
      price: Number(form.price),
      duration: Number(form.duration),
      discount: Number(form.discount)
    });
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.4)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 1000
      }}
    >
      <div className="card" style={{ width: 420 }}>
        <h4 style={{ marginBottom: 12 }}>
          {initial ? "Edit Service" : "Add Service"}
        </h4>

        <input name="name" placeholder="Service name" value={form.name} onChange={handleChange} />
        <input name="category" placeholder="Category" value={form.category} onChange={handleChange} />
        <input type="number" name="price" placeholder="Price" value={form.price} onChange={handleChange} />
        <input type="number" name="duration" placeholder="Duration (min)" value={form.duration} onChange={handleChange} />
        <input type="number" name="discount" placeholder="Discount %" value={form.discount} onChange={handleChange} />

        <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
          <button className="btn" onClick={submit}>Save</button>
          <button className="btn" style={{ background: "#eee", color: "#000" }} onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================= USERS TAB ================= */

function UsersTab() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const data = await getAllUsers();
    setUsers(data);
    setLoading(false);
  };

  const toggle = async (id) => {
    const updated = await toggleUserStatus(id);
    setUsers((u) =>
      u.map((x) => (x.userId === id ? { ...x, active: updated.active } : x))
    );
  };

  if (loading) return <p>Loading users...</p>;

  return (
    <div className="card" style={{ padding: 20 }}>
      <h4 style={{ marginBottom: 16 }}>All Users</h4>

      <div style={{ maxHeight: 420, overflowY: "auto" }}>
        <table style={{ width: "100%", fontSize: 14 }}>
          <thead style={{ position: "sticky", top: 0, background: "#fff" }}>
            <tr>
              {["Name", "Email", "Phone", "Role", "Status", "Action"].map((h) => (
                <th key={h} style={th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => {
              const isAdmin = u.userRole === "ADMIN";
              return (
                <tr key={u.userId} style={{ background: i % 2 ? "#fafafa" : "#fff" }}>
                  <td style={td}>{u.fullName}</td>
                  <td style={td}>{u.email}</td>
                  <td style={td}>{u.phone}</td>
                  <td style={td}>{u.userRole}</td>
                  <td style={td}>{u.active ? "Active" : "Inactive"}</td>
                  <td style={td}>
                    {isAdmin ? (
                      <button className="btn" disabled style={{ padding: "6px 14px", borderRadius: 999, opacity: 0.5 }}>
                        Not Allowed
                      </button>
                    ) : (
                      <button
                        className="btn"
                        style={{ padding: "6px 14px", borderRadius: 999 }}
                        onClick={() => toggle(u.userId)}
                      >
                        {u.active ? "Deactivate" : "Activate"}
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ================= BOOKINGS TAB ================= */

function BookingsTab() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const data = await getAllAppointments();
    setAppointments(data);
    setLoading(false);
  };

  if (loading) return <p>Loading bookings...</p>;
  if (appointments.length === 0) return <p>No bookings found</p>;

  return (
    <div className="card" style={{ padding: 20 }}>
      <h4 style={{ marginBottom: 16 }}>All Bookings</h4>

      <div style={{ maxHeight: 420, overflowY: "auto" }}>
        <table style={{ width: "100%", fontSize: 14 }}>
          <thead style={{ position: "sticky", top: 0, background: "#fff" }}>
            <tr>
              {["ID", "Date", "Time", "Location", "Customer", "Professional", "Services", "Amount", "Status", "Payment"]
                .map((h) => (
                  <th key={h} style={th}>{h}</th>
                ))}
            </tr>
          </thead>
          <tbody>
            {appointments.map((a, i) => {
              const dt = new Date(a.dateTime);
              return (
                <tr key={a.appointmentId} style={{ background: i % 2 ? "#fafafa" : "#fff" }}>
                  <td style={td}>{a.appointmentId}</td>
                  <td style={td}>{dt.toLocaleDateString("en-GB")}</td>
                  <td style={td}>{dt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</td>
                  <td style={td}>{a.location}</td>
                  <td style={td}>{a.customerName}</td>
                  <td style={td}>{a.professionalName ?? "—"}</td>
                  <td style={td}>{a.bookedServiceIds.length}</td>
                  <td style={td}>₹{a.amount}</td>
                  <td style={td}><StatusBadge status={a.status} /></td>
                  <td style={td}>{a.paymentStatus ?? "PENDING"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ================= SHARED ================= */

const th = { padding: "10px 12px", textAlign: "left", borderBottom: "1px solid #eee" };
const td = { padding: "10px 12px", borderBottom: "1px solid #f0f0f0", whiteSpace: "nowrap" };

function StatusBadge({ status }) {
  let bg = "#999";
  if (status === "REQUESTED") bg = "#f57c00";
  if (status === "ACCEPTED") bg = "#1976d2";
  if (status === "CONFIRMED") bg = "#512da8";
  if (status === "IN_PROGRESS") bg = "#0288d1";
  if (status === "COMPLETED") bg = "green";

  return (
    <span style={{ padding: "4px 12px", borderRadius: 999, fontSize: 12, color: "#fff", background: bg }}>
      {status}
    </span>
  );
}

/* ================= PROFESSIONALS TAB ================= */

function ProfessionalsTab() {
  const [list, setList] = useState([]);

  useEffect(() => {
    getPendingProfessionals().then(setList);
  }, []);

  if (list.length === 0) {
    return <p>No professionals pending approval</p>;
  }

  return (
    <div style={{ display: "grid", gap: 16 }}>
      {list.map((p) => (
        <div key={p.userId} className="card" style={{ padding: 18 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 24
            }}
          >
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <strong style={{ fontSize: 16 }}>{p.fullName}</strong>
              <span style={{ fontSize: 13, color: "#666" }}>{p.email}</span>
              <span style={{ fontSize: 13 }}>
                📞 {p.phone} • {p.gender}
              </span>
              <span style={{ fontSize: 13 }}>
                💼 {p.speciality} • {p.experienceInYears ?? 0} yrs
              </span>
            </div>

            <button
              className="approve-btn"
              onClick={() => approveProfessional(p.id)}
            >
              Approve
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ================= OVERVIEW TAB ================= */

function OverviewTab({ setActiveTab }) {
  const [pending, setPending] = useState(0);
  const [todayBookings, setTodayBookings] = useState(0);
  const [activeServices, setActiveServices] = useState(0);
  const [usersCount, setUsersCount] = useState(0);

  useEffect(() => {
    getPendingProfessionals().then((d) => setPending(d.length));
    getAllUsers().then((d) => setUsersCount(d.length));
    getAllBeautyServices().then((d) => setActiveServices(d.filter(s => s.active).length));
    getAllAppointments().then((d) => {
      const today = new Date().toDateString();
      setTodayBookings(
        d.filter(a => new Date(a.dateTime).toDateString() === today).length
      );
    });
  }, []);

  return (
    <div className="admin-overview">

      <div className="overview-stats">
        <div className="stat-card">
          <span className="stat-label">Pending Professionals</span>
          <span className="stat-value">{pending}</span>
        </div>

        <div className="stat-card">
          <span className="stat-label">Today’s Bookings</span>
          <span className="stat-value">{todayBookings}</span>
        </div>

        <div className="stat-card">
          <span className="stat-label">Active Services</span>
          <span className="stat-value">{activeServices}</span>
        </div>

        <div className="stat-card">
          <span className="stat-label">Total Users</span>
          <span className="stat-value">{usersCount}</span>
        </div>
      </div>

      <div className="card overview-section">
        <h3>Needs Attention</h3>
        <button
          className="overview-link-btn"
          onClick={() => setActiveTab("professionals")}
        >
          View all professionals
        </button>
      </div>

      <div className="card overview-section">
        <h3>Quick Actions</h3>

        <div className="quick-actions">
          <button className="pill-btn" onClick={() => setActiveTab("services")}>
            + Add Service
          </button>
          <button className="pill-btn" onClick={() => setActiveTab("professionals")}>
            View Professionals
          </button>
          <button className="pill-btn" onClick={() => setActiveTab("bookings")}>
            View Bookings
          </button>
        </div>
      </div>

    </div>
  );
}
