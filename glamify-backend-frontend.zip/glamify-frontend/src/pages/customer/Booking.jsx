// Booking.jsx
import { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { CartContext } from "../../context/CartContext";
import CenterContainer from "../../components/CenterContainer";
import FakeRazorpay from "../../components/FakeRazorpay";

const TIME_SLOTS = [
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "14:00",
  "16:00",
  "18:00"
];

const WORK_END_MINUTES = 18 * 60;

export default function Booking() {
  const { cart, clearCart } = useContext(CartContext);
  const navigate = useNavigate();

  const [date, setDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [address, setAddress] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPayment, setShowPayment] = useState(false);

  const token = localStorage.getItem("token");
  const today = new Date().toISOString().split("T")[0];

  /* ======================
     PRICE CALCULATION
     ====================== */
  const subtotal = cart.reduce((sum, s) => sum + s.price, 0);

  const discount = cart.reduce(
    (sum, s) =>
      s.discount > 0 ? sum + (s.price * s.discount) / 100 : sum,
    0
  );

  const total = subtotal - discount;

  /* ======================
     DURATION CALCULATION
     ====================== */
  const totalMinutes = cart.reduce(
    (sum, s) => sum + (s.duration || 0),
    0
  );

  const formatDuration = (mins) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  };

  /* ======================
     TIME HELPERS
     ====================== */
  const timeToMinutes = (time) => {
    const [h, m] = time.split(":").map(Number);
    return h * 60 + m;
  };

  const minutesToTime = (mins) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  };

  // ✅ ADDED: 12-hour formatter
  const to12Hour = (time) => {
    if (!time) return "";
    let [h, m] = time.split(":").map(Number);
    const ampm = h >= 12 ? "PM" : "AM";
    h = h % 12 || 12;
    return `${h}:${String(m).padStart(2, "0")} ${ampm}`;
  };

  const isSlotDisabled = (slot) =>
    timeToMinutes(slot) + totalMinutes > WORK_END_MINUTES;

  const endTime =
    selectedSlot &&
    minutesToTime(timeToMinutes(selectedSlot) + totalMinutes);

  /* ======================
     FORM VALIDATION
     ====================== */
  const isFormValid =
    date &&
    selectedSlot &&
    address.trim() !== "" &&
    cart.length > 0 &&
    !loading;

  /* ======================
     FINAL BOOKING API
     ====================== */
  const handleConfirm = async (paymentId) => {
    setLoading(true);
    setError("");

    try {
      const payload = {
        dateTime: `${date}T${selectedSlot}:00`,
        location: address,
        serviceIds: cart.map((s) => s.id),
        paymentId
      };

      const res = await fetch(
        "http://localhost:8080/api/customer/appointment",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        }
      );

      if (!res.ok) {
        throw new Error("Booking failed");
      }

      clearCart();
      navigate("/booking/success");
    } catch (err) {
      setError("Failed to confirm booking. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <CenterContainer>
      {/* BACK BUTTON */}
      <button
        onClick={() => navigate("/customer")}
        style={{
          marginBottom: 20,
          display: "inline-flex",
          alignItems: "center",
          gap: 8,
          padding: "8px 14px",
          borderRadius: 999,
          border: "1px solid #ddd",
          background: "#fff",
          color: "#333",
          fontSize: 14,
          fontWeight: 500,
          cursor: "pointer",
          boxShadow: "0 2px 6px rgba(0,0,0,0.08)",
          transition: "all 0.2s ease"
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = "#f7f7f7";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = "#fff";
        }}
      >
        ◁ Go Back
      </button>

      <div className="card" style={{ maxWidth: 600, margin: "0 auto" }}>
        <h2 style={{ textAlign: "center", marginBottom: 24 }}>
          Book Your Service
        </h2>

        {/* DATE + TIME */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 16,
            marginBottom: 12
          }}
        >
          <input
            className="booking-input"
            type="date"
            value={date}
            min={today}
            onChange={(e) => {
              setDate(e.target.value);
              setSelectedSlot("");
            }}
          />

          <select
            className="booking-input"
            value={selectedSlot}
            onChange={(e) => setSelectedSlot(e.target.value)}
          >
            <option value="">Select time slot</option>
            {TIME_SLOTS.map((slot) => (
              <option
                key={slot}
                value={slot}
                disabled={isSlotDisabled(slot)}
              >
                {to12Hour(slot)}
                {isSlotDisabled(slot) ? " (Unavailable)" : ""}
              </option>
            ))}
          </select>
        </div>

        {selectedSlot && (
          <div style={{ fontSize: 13, color: "#555", marginBottom: 16 }}>
            ⏱ Start Time: <strong>{to12Hour(selectedSlot)}</strong>
            <div>
              ⏱ End Time: <strong>{to12Hour(endTime)}</strong>
            </div>
          </div>
        )}

        {/* ADDRESS */}
        <textarea
          placeholder="Service address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          rows={3}
          style={{
            width: "100%",
            padding: 14,
            borderRadius: 12,
            border: "1px solid #ddd",
            marginBottom: 16,
            resize: "none"
          }}
        />

        {/* SERVICES */}
        <div style={{ marginBottom: 12 }}>
          <h4>Selected Services</h4>
          {cart.map((s) => {
            const discountedPrice = Math.round(
              s.discount
                ? s.price - (s.price * s.discount) / 100
                : s.price
            );

            return (
              <div
                key={s.id}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  fontSize: 14
                }}
              >
                <span>{s.name}</span>
                <span>
                  {s.discount > 0 && (
                    <span
                      style={{
                        textDecoration: "line-through",
                        color: "#999",
                        marginRight: 15
                      }}
                    >
                      ₹{s.price}
                    </span>
                  )}
                  ₹{discountedPrice}
                </span>
              </div>
            );
          })}
        </div>

        <div style={{ fontSize: 13, marginBottom: 16 }}>
          ⏱ Total duration: <strong>{formatDuration(totalMinutes)}</strong>
        </div>

        {/* PRICE SUMMARY */}
        <div style={{ fontSize: 14, marginBottom: 20 }}>
          <hr />
          <div>
            Subtotal <span style={{ float: "right" }}>₹{subtotal}</span>
          </div>
          <div style={{ color: "green" }}>
            Discount <span style={{ float: "right" }}>-₹{discount}</span>
          </div>
          <hr />
          <strong>
            Total <span style={{ float: "right" }}>₹{total}</span>
          </strong>
        </div>

        {error && (
          <p style={{ color: "red", fontSize: 13 }}>{error}</p>
        )}

        {/* PAY BUTTON */}
        <button
          className="btn"
          disabled={!isFormValid}
          onClick={() => setShowPayment(true)}
          style={{
            opacity: isFormValid ? 1 : 0.6,
            cursor: isFormValid ? "pointer" : "not-allowed"
          }}
        >
          Pay ₹{Math.round(total)}
        </button>
      </div>

      {/* FAKE PAYMENT MODAL */}
      {showPayment && (
        <FakeRazorpay
          amount={Math.round(total)}
          onClose={() => setShowPayment(false)}
          onSuccess={(paymentId) => {
            setShowPayment(false);
            handleConfirm(paymentId);
          }}
        />
      )}
    </CenterContainer>
  );
}
