import { useNavigate } from "react-router-dom";
import CenterContainer from "../../components/CenterContainer";


export default function BookingSuccess() {
  const navigate = useNavigate();

  return (
    <CenterContainer>
        
      <div
        className="card"
        style={{
          maxWidth: 500,
          margin: "0 auto",
          textAlign: "center"
        }}
      >
        <h2 style={{ marginBottom: 12 }}>🎉 Booking Confirmed</h2>

        <p style={{ color: "#555", marginBottom: 24 }}>
          Your service has been successfully booked.
          Our professional will arrive at the selected time.
        </p>

        <button
          className="btn"
          onClick={() => navigate("/customer")}
          style={{ marginBottom: 12 }}
        >
          Go to Home
        </button>
      </div>
    </CenterContainer>
  );
}
