import { useEffect, useState } from "react";
import CenterContainer from "../../components/CenterContainer";

export default function BookingHistory({ renderTabs }) {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // ======================
  // PAGINATION (ADDED)
  // ======================
  const ITEMS_PER_PAGE = 5;
  const [currentPage, setCurrentPage] = useState(1);

  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const res = await fetch(
          "http://localhost:8080/api/customer/appointments",
          {
            headers: {
              Authorization: `Bearer ${token}`
            }
          }
        );

        if (!res.ok) {
          throw new Error("Failed to fetch appointments");
        }

        const data = await res.json();
        setAppointments(data);
        setCurrentPage(1); // reset page when data loads
      } catch (err) {
        setError("Unable to load booking history");
      } finally {
        setLoading(false);
      }
    };

    fetchAppointments();
  }, [token]);

  /* ======================
     Helpers
     ====================== */
  const formatDateTime = (dateTime) => {
    const d = new Date(dateTime);

    const day = String(d.getDate()).padStart(2, "0");
    const month = d.toLocaleString("en-US", { month: "short" });
    const year = d.getFullYear();

    let hours = d.getHours();
    const minutes = String(d.getMinutes()).padStart(2, "0");
    const ampm = hours >= 12 ? "PM" : "AM";

    hours = hours % 12;
    hours = hours === 0 ? 12 : hours;

    return `${day}-${month}-${year}, ${hours}:${minutes} ${ampm}`;
  };

  const formatDuration = (minutes) => {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case "COMPLETED":
        return { background: "#e6f4ea", color: "green" };
      case "IN_PROGRESS":
        return { background: "#e8f0fe", color: "#1a73e8" };
      case "CONFIRMED":
        return { background: "#fff4e5", color: "#b26a00" };
      case "CANCELLED":
        return { background: "#fdecea", color: "#d93025" };
      default:
        return { background: "#eee", color: "#555" };
    }
  };

  // ======================
  // PAGINATION LOGIC (ADDED)
  // ======================
  const totalPages = Math.ceil(
    appointments.length / ITEMS_PER_PAGE
  );

  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const paginatedAppointments = appointments.slice(
    startIndex,
    startIndex + ITEMS_PER_PAGE
  );

  return (
    <div style={{ maxWidth: 900, margin: "0 auto" }}>
      <h2 style={{ textAlign: "center", marginBottom: 24 }}>
        My Bookings
      </h2>

      {loading && (
        <p style={{ textAlign: "center" }}>Loading…</p>
      )}

      {error && (
        <p style={{ textAlign: "center", color: "red" }}>
          {error}
        </p>
      )}

      {!loading && appointments.length === 0 && (
        <p style={{ textAlign: "center", color: "#777" }}>
          No bookings found
        </p>
      )}

      {paginatedAppointments.map((a) => (
        <div
          key={a.appointmentId}
          className="card"
          style={{ marginBottom: 20 }}
        >
          {/* HEADER */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 14
            }}
          >
            <strong>{formatDateTime(a.dateTime)}</strong>

            <span
              style={{
                fontSize: 12,
                padding: "4px 12px",
                borderRadius: 14,
                ...getStatusStyle(a.status)
              }}
            >
              {a.status}
            </span>
          </div>

          {/* CONTENT GRID */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1.2fr 1fr",
              gap: 32
            }}
          >
            {/* LEFT SIDE – DETAILS */}
            <div style={{ fontSize: 14 }}>
              <div style={{ marginBottom: 8 }}>
                📍 {a.location}
              </div>

              <div style={{ marginBottom: 8 }}>
                👩‍🔧 Professional:{" "}
                <strong>
                  {a.professionalName || "Not assigned yet"}
                </strong>
              </div>

              <div style={{ marginBottom: 8 }}>
                ⏱ Total Time:{" "}
                <strong>
                  {formatDuration(a.totalEstimatedTime)}
                </strong>
              </div>

              <div style={{ marginBottom: 8 }}>
                🧾 Invoice:{" "}
                <strong>
                  {a.invoiceNumber || "Not generated"}
                </strong>
              </div>

              <div style={{ fontWeight: 600 }}>
                💰 Amount Paid: ₹{a.amount}
              </div>
            </div>

            {/* RIGHT SIDE – SERVICES */}
            <div style={{ fontSize: 14 }}>
              <strong>Services</strong>
              <ul style={{ paddingLeft: 18, marginTop: 8 }}>
                {a.services.map((s, idx) => (
                  <li key={idx} style={{ marginBottom: 4 }}>
                    {s.serviceName} ({s.estimatedTime} min)
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      ))}

      {/* ======================
          PAGINATION CONTROLS (ADDED)
         ====================== */}
      {totalPages > 1 && (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 8,
            marginTop: 24
          }}
        >
          <button
            className="btn"
            style={{ width: "auto", padding: "8px 14px" }}
            disabled={currentPage === 1}
            onClick={() => setCurrentPage((p) => p - 1)}
          >
            Prev
          </button>

          {Array.from({ length: totalPages }).map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPage(i + 1)}
              style={{
                padding: "8px 14px",
                borderRadius: 10,
                border: "1px solid #ddd",
                background:
                  currentPage === i + 1 ? "#000" : "#fff",
                color:
                  currentPage === i + 1 ? "#fff" : "#000",
                cursor: "pointer"
              }}
            >
              {i + 1}
            </button>
          ))}

          <button
            className="btn"
            style={{ width: "auto", padding: "8px 14px" }}
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage((p) => p + 1)}
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
