import { useState, useRef, useEffect, forwardRef } from "react";
import CenterContainer from "../../components/CenterContainer";
import CustomerDashboard from "./CustomerDashboard";
import BookingHistory from "./BookingHistory";

export default function CustomerTabs() {
  const [activeTab, setActiveTab] = useState("SERVICES");

  return (
    <CenterContainer>
      
      <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />

      <div style={{ position: "relative", overflow: "hidden" }}>
        <Pane show={activeTab === "SERVICES"}>
          <CustomerDashboard />
        </Pane>

        <Pane show={activeTab === "HISTORY"}>
          <BookingHistory />
        </Pane>
      </div>
    </CenterContainer>
  );
}

/* ---------- Visibility Pane (no remount) ---------- */

function Pane({ show, children }) {
  return (
    <div
      style={{
        position: show ? "relative" : "absolute",
        inset: 0,
        opacity: show ? 1 : 0,
        transform: show ? "translateY(0)" : "translateY(6px)",
        pointerEvents: show ? "auto" : "none",
        transition: "opacity 200ms ease, transform 200ms ease",
      }}
    >
      {children}
    </div>
  );
}

/* ---------- Tabs ---------- */

function Tabs({ activeTab, setActiveTab }) {
  const servicesRef = useRef(null);
  const historyRef = useRef(null);
  const [indicator, setIndicator] = useState({ left: 0, width: 0 });

  useEffect(() => {
    const el =
      activeTab === "SERVICES"
        ? servicesRef.current
        : historyRef.current;

    if (!el) return;

    requestAnimationFrame(() => {
      setIndicator({
        left: el.offsetLeft,
        width: el.offsetWidth,
      });
    });
  }, [activeTab]);

  return (
    <div
      style={{
        position: "relative",
        display: "inline-flex",
        background: "#f1f1f1",
        borderRadius: 999,
        padding: 4,
        margin: "12px 0 24px",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 4,
          bottom: 4,
          left: indicator.left,
          width: indicator.width,
          background: "#000",
          borderRadius: 999,
          transition:
            "left 260ms cubic-bezier(.4,0,.2,1), width 260ms cubic-bezier(.4,0,.2,1)",
        }}
      />

      <TabButton
        ref={servicesRef}
        active={activeTab === "SERVICES"}
        onClick={() => setActiveTab("SERVICES")}
      >
        Book Services
      </TabButton>

      <TabButton
        ref={historyRef}
        active={activeTab === "HISTORY"}
        onClick={() => setActiveTab("HISTORY")}
      >
        Booking History
      </TabButton>
    </div>
  );
}

const TabButton = forwardRef(function TabButton(
  { active, children, ...props },
  ref
) {
  return (
    <button
      ref={ref}
      {...props}
      style={{
        zIndex: 1,
        padding: "10px 18px",
        borderRadius: 999,
        border: "none",
        background: "transparent",
        fontWeight: 600,
        cursor: "pointer",
        color: active ? "#fff" : "#333",
        transition: "color 200ms ease",
      }}
    >
      {children}
    </button>
  );
});
