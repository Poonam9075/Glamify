import { useEffect, useState } from "react";
import CenterContainer from "../../components/CenterContainer";
import ServiceCard from "../../components/ServiceCard";
import Cart from "../../components/Cart";
import { getAllServices } from "../../api/serviceApi";

export default function CustomerDashboard({ renderTabs }) {
  const [services, setServices] = useState([]);
  const [filteredServices, setFilteredServices] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("ALL");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  /* ======================
     PAGINATION (ADDED)
     ====================== */
  const ITEMS_PER_PAGE = 6;
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    getAllServices()
      .then((data) => {
        const activeServices = data.filter((s) => s.active);
        setServices(activeServices);
        setFilteredServices(activeServices);

        const uniqueCategories = [
          "ALL",
          ...new Set(activeServices.map((s) => s.category))
        ];
        setCategories(uniqueCategories);
      })
      .catch(() => setError("Failed to load services"))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (selectedCategory === "ALL") {
      setFilteredServices(services);
    } else {
      setFilteredServices(
        services.filter((s) => s.category === selectedCategory)
      );
    }
    setCurrentPage(1); // reset page on category change
  }, [selectedCategory, services]);

  if (loading) {
    return (
      <CenterContainer>
        <h3>Loading services...</h3>
      </CenterContainer>
    );
  }

  if (error) {
    return (
      <CenterContainer>
        <h3 style={{ color: "red" }}>{error}</h3>
      </CenterContainer>
    );
  }

  /* ======================
     PAGINATION LOGIC
     ====================== */
  const totalPages = Math.ceil(
    filteredServices.length / ITEMS_PER_PAGE
  );

  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const paginatedServices = filteredServices.slice(
    startIndex,
    startIndex + ITEMS_PER_PAGE
  );

  return (
    <CenterContainer>
      {renderTabs && renderTabs()}

      <div style={{ minHeight: "auto" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "2.5fr 1fr",
            gap: 24,
            alignItems: "flex-start"
          }}
        >
          {/* LEFT PARTITION – SERVICES */}
          <div className="card">
            <h2 style={{ textAlign: "center", marginBottom: 16 }}>
              Select Services
            </h2>

            {/* CATEGORY FILTERS */}
            <div className="category-filter">
              {categories.map((cat) => (
                <button
                  key={cat}
                  className={`category-btn ${
                    selectedCategory === cat ? "active" : ""
                  }`}
                  onClick={() => setSelectedCategory(cat)}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* SERVICES GRID */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(220px, 1fr))",
                gap: 20
              }}
            >
              {paginatedServices.map((service) => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </div>

            {/* PAGINATION CONTROLS */}
            {totalPages > 1 && (
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  gap: 8,
                  marginTop: 24
                }}
              >
                <button
                  className="btn"
                  style={{ width: "auto", padding: "8px 14px" }}
                  disabled={currentPage === 1}
                  onClick={() =>
                    setCurrentPage((p) => p - 1)
                  }
                >
                  Prev
                </button>

                {Array.from({ length: totalPages }).map(
                  (_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentPage(i + 1)}
                      style={{
                        padding: "8px 14px",
                        borderRadius: 10,
                        border: "1px solid #ddd",
                        background:
                          currentPage === i + 1
                            ? "#000"
                            : "#fff",
                        color:
                          currentPage === i + 1
                            ? "#fff"
                            : "#000",
                        cursor: "pointer"
                      }}
                    >
                      {i + 1}
                    </button>
                  )
                )}

                <button
                  className="btn"
                  style={{ width: "auto", padding: "8px 14px" }}
                  disabled={currentPage === totalPages}
                  onClick={() =>
                    setCurrentPage((p) => p + 1)
                  }
                >
                  Next
                </button>
              </div>
            )}
          </div>

          {/* RIGHT PARTITION – CART (STICKY) */}
          <div
            style={{
              position: "sticky",
              top: 96
            }}
          >
            <Cart />
          </div>
        </div>
      </div>
    </CenterContainer>
  );
}
