import { useState } from "react";
import { useNavigate } from "react-router-dom";
import CenterContainer from "../../components/CenterContainer";
import { registerCustomer, registerProfessional } from "../../api/authApi";

import logo from "../../assets/glamify-logo.png";

export default function Register() {
  const navigate = useNavigate();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("CUSTOMER");
  const [gender, setGender] = useState("FEMALE");
  const [speciality, setSpeciality] = useState("");

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const isProfessional = role === "PROFESSIONAL";

  const handleRegister = async () => {
    setError("");
    setLoading(true);

    try {
      if (isProfessional) {
        await registerProfessional({
          fullName,
          email,
          phone,
          password,
          gender,
          role,
          speciality
        });
      } else {
        await registerCustomer({
          fullName,
          email,
          phone,
          password,
          gender,
          role
        });
      }

      navigate("/login");
    } catch {
      setError("Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <CenterContainer centerVertically>
      <div
        className="card login-card"
        style={{
          maxWidth: 420,
          width: "100%",
          textAlign: "center",
          padding: "clamp(24px, 4vw, 32px)" // 🔹 reduces height on small screens
        }}
      >
        {/* LOGO */}
        <div className="login-logo-wrapper">
          <img src={logo} alt="Glamify" className="login-logo" />
        </div>

        <p className="login-subtitle">
          Create an account to start booking services
        </p>

        <div style={{ display: "flex", flexDirection: "column" }}>
          <input
            type="text"
            placeholder="Full name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
          />

          <input
            type="email"
            name="email"
            autoComplete="email"
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            />

          <input
            type="tel"
            name="phone"
            autoComplete="tel"
            placeholder="Phone number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            />  

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          {/* GENDER */}
          <select
            className="booking-input"
            style={{ marginBottom: 14 }}
            value={gender}
            onChange={(e) => setGender(e.target.value)}
          >
            <option value="FEMALE">Female</option>
            <option value="MALE">Male</option>
          </select>

          {/* ROLE (moved above gender) */}
          <select
            className="booking-input"
            style={{ marginBottom: 14 }}
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="CUSTOMER">Customer</option>
            <option value="PROFESSIONAL">Professional</option>
          </select>

          {/* SPECIALITY — animated */}
          <div
            style={{
              overflow: "hidden",
              maxHeight: isProfessional ? 60 : 0,
              opacity: isProfessional ? 1 : 0,
              transform: isProfessional
                ? "translateY(0)"
                : "translateY(-6px)",
              transition: "all 0.25s ease"
            }}
          >
            {isProfessional && (
              <input
                type="text"
                placeholder="Speciality"
                value={speciality}
                onChange={(e) => setSpeciality(e.target.value)}
              />
            )}
          </div>

          {error && (
            <p style={{ color: "red", fontSize: 13, marginBottom: 12 }}>
              {error}
            </p>
          )}

          <button className="btn" onClick={handleRegister}>
            {loading ? "Creating account..." : "Register"}
          </button>

          <p style={{ marginTop: 16, fontSize: 13 }}>
            Already have an account?{" "}
            <span
              onClick={() => navigate("/login")}
              style={{
                color: "var(--primary)",
                cursor: "pointer",
                fontWeight: 500
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.textDecoration = "underline")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.textDecoration = "none")
              }
            >
              Login
            </span>
          </p>
        </div>

        <p style={{ marginTop: 24, fontSize: 12, color: "#888" }}>
          © Glamify Personal Care Services
        </p>
      </div>
    </CenterContainer>
  );
}
