import { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import CenterContainer from "../../components/CenterContainer";
import { AuthContext } from "../../context/AuthContext";
import { loginUser } from "../../api/authApi";

import logo from "../../assets/glamify-logo.png";

export default function Login() {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setError("");
    setLoading(true);

    try {
      const data = await loginUser({ email, password });
      login(data);

      if (data.role === "ADMIN") navigate("/admin");
      else if (data.role === "PROFESSIONAL") navigate("/professional");
      else navigate("/customer");
    } catch {
      setError("Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  return (
    <CenterContainer centerVertically>
      <div
        className="card login-card"
        style={{
          maxWidth: 420,
          width: "100%",
          textAlign: "center"
        }}
      >
        {/* LOGO */}
        <div className="login-logo-wrapper">
          <img src={logo} alt="Glamify" className="login-logo" />
        </div>

        <p className="login-subtitle">
          Login to continue booking services
        </p>

        <div style={{ display: "flex", flexDirection: "column" }}>
          <input
            type="email"
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          {error && (
            <p style={{ color: "red", fontSize: 13, marginBottom: 12 }}>
              {error}
            </p>
          )}

          <button className="btn" onClick={handleLogin}>
            {loading ? "Logging in..." : "Login"}
          </button>

          {/* 👇 VISUAL LINK FIX */}
          <p style={{ marginTop: 16, fontSize: 13 }}>
            Don’t have an account?{" "}
            <span
              onClick={() => navigate("/register")}
              style={{
                color: "var(--primary)",
                cursor: "pointer",
                fontWeight: 500
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.textDecoration = "underline")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.textDecoration = "none")
              }
            >
              Register
            </span>
          </p>
        </div>

        <p style={{ marginTop: 24, fontSize: 12, color: "#888" }}>
          © Glamify Personal Care Services
        </p>
      </div>
    </CenterContainer>
  );
}
