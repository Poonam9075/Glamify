// ProfessionalDashboard.jsx

import { useEffect, useState, useContext, useRef } from "react";
import CenterContainer from "../../components/CenterContainer";
import { AuthContext } from "../../context/AuthContext";
import api from "../../api/axios";

export default function ProfessionalDashboard({ renderTabs }) {
  const { user } = useContext(AuthContext);

  const [appointments, setAppointments] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);

  const detailsRef = useRef(null);

  useEffect(() => {
    api
      .get("/api/professional/appointments")
      .then((res) => setAppointments(res.data || []))
      .finally(() => setLoading(false));
  }, []);

  const updateStatus = async (id, status) => {
    await api.put(`/api/professional/appointments/${id}/status`, { status });

    setAppointments((prev) =>
      prev.map((a) =>
        a.appointmentId === id ? { ...a, status } : a
      )
    );

    setSelected(null);
  };

  /* ---------- Auto-scroll when details open ---------- */

  useEffect(() => {
    if (selected && detailsRef.current) {
      detailsRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  }, [selected]);

  /* ---------- Formatting ---------- */

  const formatDate = (dt) => {
    const d = new Date(dt);
    const day = String(d.getDate()).padStart(2, "0");
    const month = d.toLocaleString("en-US", { month: "short" });
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const formatTime = (dt) =>
    new Date(dt).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });

  /* ---------- Summary ---------- */

  const today = new Date().toISOString().split("T")[0];

  const todayCount = appointments.filter((a) =>
    a.dateTime.startsWith(today)
  ).length;

  const upcomingCount = appointments.filter(
    (a) => a.status === "ACCEPTED"
  ).length;

  const totalRevenue = appointments.reduce(
    (sum, a) => sum + (a.amount || 0),
    0
  );

  const totalMinutes = appointments.reduce(
    (sum, a) => sum + (a.totalEstimatedTime || 0),
    0
  );

  if (loading) {
    return (
      <CenterContainer>
        <h3>Loading appointments...</h3>
      </CenterContainer>
    );
  }

  return (
    <CenterContainer>
      {renderTabs && renderTabs()}

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "2.5fr 1fr",
          gap: 28,
          alignItems: "flex-start",
        }}
      >
        {/* LEFT CARD */}
        <div className="card" style={{ padding: 28 }}>
          <h2 style={{ textAlign: "center", marginBottom: 24 }}>
            My Assigned Appointments
          </h2>

          <table style={{ width: "100%", borderSpacing: "0 12px" }}>
            <thead>
              <tr>
                {["Customer", "Services", "Date", "Time", "Status", "Payment"].map(
                  (h) => (
                    <th key={h} style={thStyle}>{h}</th>
                  )
                )}
              </tr>
            </thead>

            <tbody>
              {appointments.map((a) => {
                const isSelected =
                  selected?.appointmentId === a.appointmentId;

                return (
                  <tr
                    key={a.appointmentId}
                    style={{
                      ...rowStyle,
                      background: isSelected ? "#eef6ff" : "#fafafa",
                      outline: isSelected
                        ? "2px solid #90caf9"
                        : "none",
                    }}
                    onClick={() => setSelected(a)}
                  >
                    <td style={tdStyle}>{a.customerName}</td>

                    <td style={tdStyle}>
                      <ul style={{ paddingLeft: 18, margin: 0 }}>
                        {a.services.map((s, i) => (
                          <li key={i}>
                            {s.serviceName}
                            <span style={{ color: "#888" }}>
                              {" "}({s.estimatedTime} min)
                            </span>
                          </li>
                        ))}
                      </ul>
                    </td>

                    <td style={{ ...tdStyle, whiteSpace: "nowrap" }}>
                      {formatDate(a.dateTime)}
                    </td>

                    <td style={{ ...tdStyle, whiteSpace: "nowrap" }}>
                      {formatTime(a.dateTime)}
                    </td>

                    <td style={{ ...tdStyle, whiteSpace: "nowrap" }}>
                      <StatusPill status={a.status} />
                    </td>

                    <td style={{ ...tdStyle, whiteSpace: "nowrap" }}>
                      <PaymentPill />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* ✅ INLINE DETAILS (Animated) */}
          <div
            ref={detailsRef}
            style={{
              maxHeight: selected ? 1000 : 0,
              opacity: selected ? 1 : 0,
              overflow: "hidden",
              transition:
                "max-height 300ms ease, opacity 250ms ease",
              marginTop: selected ? 28 : 0,
              paddingTop: selected ? 20 : 0,
              borderTop: selected ? "1px solid #eee" : "none",
            }}
          >
            {selected && (
              <>
                <h3 style={{ marginBottom: 12 }}>
                  Appointment Details
                </h3>

                <p><strong>Customer:</strong> {selected.customerName}</p>
                <p><strong>Date:</strong> {formatDate(selected.dateTime)}</p>
                <p><strong>Time:</strong> {formatTime(selected.dateTime)}</p>
                <p><strong>Invoice:</strong> {selected.invoiceNumber}</p>
                <p><strong>Amount:</strong> ₹ {selected.amount}</p>

                <h4 style={{ marginTop: 12 }}>Services</h4>
                <ul>
                  {selected.services.map((s, i) => (
                    <li key={i}>
                      {s.serviceName} ({s.estimatedTime} min)
                    </li>
                  ))}
                </ul>

                <div
                  style={{
                    marginTop: 20,
                    display: "flex",
                    gap: 10,
                  }}
                >
                  {selected.status === "ACCEPTED" && (
                    <>
                      <ActionBtn
                        onClick={() =>
                          updateStatus(
                            selected.appointmentId,
                            "IN_PROGRESS"
                          )
                        }
                      >
                        Start
                      </ActionBtn>
                      <ActionBtn
                        danger
                        onClick={() =>
                          updateStatus(
                            selected.appointmentId,
                            "REJECTED"
                          )
                        }
                      >
                        Reject
                      </ActionBtn>
                    </>
                  )}

                  {selected.status === "IN_PROGRESS" && (
                    <ActionBtn
                      onClick={() =>
                        updateStatus(
                          selected.appointmentId,
                          "COMPLETED"
                        )
                      }
                    >
                      Mark Completed
                    </ActionBtn>
                  )}

                  <button
                    onClick={() => setSelected(null)}
                    style={{
                      marginLeft: "auto",
                      background: "transparent",
                      border: "none",
                      cursor: "pointer",
                      color: "#555",
                    }}
                  >
                    Close
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* RIGHT CARD (UNCHANGED) */}
        <div className="card" style={{ padding: 28 }}>
          <h3 style={{ textAlign: "center", marginBottom: 20 }}>
            Today’s Summary
          </h3>

          <SummaryRow label="Professional" value={user.name} />
          <Divider />
          <SummaryRow label="Today" value={todayCount} />
          <SummaryRow label="Upcoming" value={upcomingCount} />
          <Divider />
          <SummaryRow
            label="Total Revenue"
            value={`₹ ${totalRevenue}`}
            bold
          />
          <SummaryRow
            label="Total Minutes"
            value={`${totalMinutes} min`}
          />
        </div>
      </div>
    </CenterContainer>
  );
}

/* ---------- UI Helpers (UNCHANGED) ---------- */

const thStyle = {
  textAlign: "left",
  fontSize: 13,
  color: "#555",
  paddingBottom: 10,
};

const tdStyle = {
  padding: "14px 12px",
  verticalAlign: "top",
};

const rowStyle = {
  borderRadius: 12,
  cursor: "pointer",
};

const StatusPill = ({ status }) => {
  const map = {
    ACCEPTED: ["#e6f4ea", "#1e7e34"],
    IN_PROGRESS: ["#fff3e0", "#ef6c00"],
    COMPLETED: ["#fdecea", "#c62828"],
    REJECTED: ["#fbe9e7", "#d84315"],
  };

  const [bg, color] = map[status] || ["#eee", "#333"];

  return (
    <span
      style={{
        background: bg,
        color,
        padding: "6px 14px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 600,
        whiteSpace: "nowrap",
      }}
    >
      {status.replace("_", " ")}
    </span>
  );
};

const PaymentPill = () => (
  <span
    style={{
      background: "#e3f2fd",
      color: "#0d47a1",
      padding: "6px 14px",
      borderRadius: 999,
      fontSize: 12,
      fontWeight: 600,
      whiteSpace: "nowrap",
    }}
  >
    SUCCESS
  </span>
);

const SummaryRow = ({ label, value, bold }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      margin: "8px 0",
    }}
  >
    <span style={{ color: "#666" }}>{label}</span>
    <span style={{ fontWeight: bold ? 600 : 500 }}>{value}</span>
  </div>
);

const Divider = () => (
  <div style={{ height: 1, background: "#eee", margin: "12px 0" }} />
);

const ActionBtn = ({ children, danger, ...props }) => (
  <button
    {...props}
    style={{
      padding: "10px 16px",
      borderRadius: 8,
      border: "none",
      cursor: "pointer",
      background: danger ? "#fdecea" : "#e6f4ea",
      color: danger ? "#c62828" : "#1e7e34",
      fontWeight: 600,
      whiteSpace: "nowrap",
    }}
  >
    {children}
  </button>
);
