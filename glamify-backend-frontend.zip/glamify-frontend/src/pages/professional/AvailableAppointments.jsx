// AvailableAppointments.jsx

import { useEffect, useState, useRef } from "react";
import CenterContainer from "../../components/CenterContainer";
import api from "../../api/axios";

export default function AvailableAppointments({ renderTabs }) {
  const [appointments, setAppointments] = useState([]);
  const [myAppointments, setMyAppointments] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);

  const detailsRef = useRef(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [available, mine] = await Promise.all([
        api.get("/api/professional/available-appointments"),
        api.get("/api/professional/appointments"),
      ]);
      setAppointments(available.data || []);
      setMyAppointments(mine.data || []);
    } finally {
      setLoading(false);
    }
  };

  /* ---------- Auto-scroll when details open ---------- */
  useEffect(() => {
    if (selected && detailsRef.current) {
      detailsRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  }, [selected]);

  /* ---------- Formatting ---------- */

  const formatDate = (dt) => {
    const d = new Date(dt);
    const day = String(d.getDate()).padStart(2, "0");
    const month = d.toLocaleString("en-US", { month: "short" });
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const formatTime = (dt) =>
    new Date(dt).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });

  /* ---------- Overlap Check ---------- */

  const hasOverlap = (a) => {
    const start = new Date(a.dateTime);
    const end = new Date(start.getTime() + a.totalEstimatedTime * 60000);

    return myAppointments.some((m) => {
      if (!["ACCEPTED", "IN_PROGRESS"].includes(m.status)) return false;

      const ms = new Date(m.dateTime);
      const me = new Date(ms.getTime() + m.totalEstimatedTime * 60000);

      return start < me && end > ms;
    });
  };

  const getConflictReason = (a) => {
    const start = new Date(a.dateTime);
    const end = new Date(start.getTime() + a.totalEstimatedTime * 60000);

    const conflict = myAppointments.find((m) => {
      if (!["ACCEPTED", "IN_PROGRESS"].includes(m.status)) return false;

      const ms = new Date(m.dateTime);
      const me = new Date(ms.getTime() + m.totalEstimatedTime * 60000);

      return start < me && end > ms;
    });

    if (!conflict) return null;

    return `Conflicts with another appointment on ${formatDate(
      conflict.dateTime
    )} at ${formatTime(conflict.dateTime)}`;
  };

  const acceptAppointment = async (id) => {
    await api.put(`/api/professional/appointments/${id}/accept`);

    setAppointments((prev) =>
      prev.filter((a) => a.appointmentId !== id)
    );

    // ✅ auto-collapse details after accept
    setSelected(null);
  };

  if (loading) {
    return (
      <CenterContainer>
        <h3>Loading available appointments...</h3>
      </CenterContainer>
    );
  }

  return (
    <CenterContainer>
      {renderTabs && renderTabs()}

      <div className="card" style={{ padding: 28 }}>
        <h2 style={{ textAlign: "center", marginBottom: 24 }}>
          Available Appointments
        </h2>

        {appointments.length === 0 ? (
          <p style={{ textAlign: "center", opacity: 0.7 }}>
            No available appointments right now.
          </p>
        ) : (
          <table style={{ width: "100%", borderSpacing: "0 12px" }}>
            <thead>
              <tr>
                {[
                  "Customer",
                  "Services",
                  "Date",
                  "Time",
                  "Duration",
                  "Action",
                ].map((h) => (
                  <th key={h} style={thStyle}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {appointments.map((a) => {
                const conflict = hasOverlap(a);
                const isSelected =
                  selected?.appointmentId === a.appointmentId;

                return (
                  <tr
                    key={a.appointmentId}
                    onClick={() => setSelected(a)}
                    style={{
                      ...rowStyle,
                      background: isSelected ? "#eef6ff" : "#fafafa",
                      outline: isSelected
                        ? "2px solid #90caf9"
                        : "none",
                      transition:
                        "transform 120ms ease, box-shadow 120ms ease",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "translateY(-1px)";
                      e.currentTarget.style.boxShadow =
                        "0 4px 10px rgba(0,0,0,0.06)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "translateY(0)";
                      e.currentTarget.style.boxShadow = "none";
                    }}
                  >
                    <td style={tdStyle}>{a.customerName}</td>

                    <td style={tdStyle}>
                      {a.services.map((s, i) => (
                        <div key={i}>
                          {s.serviceName}
                          <span style={{ color: "#888" }}>
                            {" "}({s.estimatedTime} min)
                          </span>
                        </div>
                      ))}
                    </td>

                    <td style={{ ...tdStyle, whiteSpace: "nowrap" }}>
                      {formatDate(a.dateTime)}
                    </td>

                    <td style={{ ...tdStyle, whiteSpace: "nowrap" }}>
                      {formatTime(a.dateTime)}
                    </td>

                    <td style={tdStyle}>
                      <span style={durationBadge}>
                        {a.totalEstimatedTime} min
                      </span>
                    </td>

                    <td style={tdStyle}>
                      <button
                        disabled={conflict}
                        onClick={(e) => {
                          e.stopPropagation();
                          acceptAppointment(a.appointmentId);
                        }}
                        title={
                          conflict
                            ? "Time overlaps with existing appointment"
                            : ""
                        }
                        style={{
                          padding: "8px 14px",
                          borderRadius: 8,
                          border: "none",
                          cursor: conflict
                            ? "not-allowed"
                            : "pointer",
                          background: conflict ? "#eee" : "#e6f4ea",
                          color: conflict ? "#999" : "#1e7e34",
                          fontWeight: 600,
                        }}
                      >
                        Accept
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}

        {/* ✅ INLINE DETAILS PANEL */}
        <div
          ref={detailsRef}
          style={{
            maxHeight: selected ? 1000 : 0,
            opacity: selected ? 1 : 0,
            overflow: "hidden",
            transition:
              "max-height 300ms ease, opacity 250ms ease",
            marginTop: selected ? 28 : 0,
            paddingTop: selected ? 20 : 0,
            borderTop: selected ? "1px solid #eee" : "none",
          }}
        >
          {selected && (
            <>
              <h3 style={{ marginBottom: 12 }}>
                Appointment Details
              </h3>

              <p><strong>Customer:</strong> {selected.customerName}</p>
              <p><strong>Date:</strong> {formatDate(selected.dateTime)}</p>
              <p><strong>Time:</strong> {formatTime(selected.dateTime)}</p>
              <p><strong>Amount:</strong> ₹ {selected.amount}</p>

              <h4 style={{ marginTop: 12 }}>Services</h4>
              <ul>
                {selected.services.map((s, i) => (
                  <li key={i}>
                    {s.serviceName} ({s.estimatedTime} min)
                  </li>
                ))}
              </ul>

              {/* ✅ conflict reason shown here */}
              {hasOverlap(selected) && (
                <div
                  style={{
                    marginTop: 12,
                    padding: "10px 14px",
                    background: "#fff3e0",
                    color: "#ef6c00",
                    borderRadius: 8,
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                >
                  ⚠ {getConflictReason(selected)}
                </div>
              )}

              <div style={{ marginTop: 20, display: "flex", gap: 10 }}>
                <button
                  onClick={() => setSelected(null)}
                  style={{
                    marginLeft: "auto",
                    background: "transparent",
                    border: "none",
                    cursor: "pointer",
                    color: "#555",
                  }}
                >
                  Close
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </CenterContainer>
  );
}

/* ---------- Styles (UNCHANGED) ---------- */

const thStyle = {
  textAlign: "left",
  fontSize: 13,
  color: "#555",
  paddingBottom: 10,
};

const tdStyle = {
  padding: "14px 12px",
  verticalAlign: "top",
};

const rowStyle = {
  borderRadius: 12,
  cursor: "pointer",
};

const durationBadge = {
  padding: "4px 10px",
  borderRadius: 8,
  background: "#f1f1f1",
  fontSize: 12,
  fontWeight: 600,
};
