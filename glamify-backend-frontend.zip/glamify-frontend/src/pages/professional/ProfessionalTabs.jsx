import { useState, useRef, useEffect, forwardRef } from "react";
import CenterContainer from "../../components/CenterContainer";
import ProfessionalDashboard from "./ProfessionalDashboard";
import AvailableAppointments from "./AvailableAppointments";

export default function ProfessionalTabs() {
  const [activeTab, setActiveTab] = useState("MY");

  return (
    <CenterContainer>
      <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />

      <div style={{ position: "relative", overflow: "hidden" }}>
        <Pane show={activeTab === "MY"}>
          <ProfessionalDashboard />
        </Pane>

        <Pane show={activeTab === "AVAILABLE"}>
          <AvailableAppointments />
        </Pane>
      </div>
    </CenterContainer>
  );
}

function Pane({ show, children }) {
  return (
    <div
      style={{
        position: show ? "relative" : "absolute",
        inset: 0,
        opacity: show ? 1 : 0,
        transform: show ? "translateY(0)" : "translateY(6px)",
        pointerEvents: show ? "auto" : "none",
        transition: "opacity 200ms ease, transform 200ms ease",
      }}
    >
      {children}
    </div>
  );
}

function Tabs({ activeTab, setActiveTab }) {
  const myRef = useRef(null);
  const availableRef = useRef(null);
  const [indicator, setIndicator] = useState({ left: 0, width: 0 });

  useEffect(() => {
    const el =
      activeTab === "MY" ? myRef.current : availableRef.current;
    if (!el) return;

    requestAnimationFrame(() => {
      setIndicator({
        left: el.offsetLeft,
        width: el.offsetWidth,
      });
    });
  }, [activeTab]);

  return (
    <div
      style={{
        position: "relative",
        display: "inline-flex",
        background: "#f1f1f1",
        borderRadius: 999,
        padding: 4,
        margin: "12px 0 24px",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 4,
          bottom: 4,
          left: indicator.left,
          width: indicator.width,
          background: "#000",
          borderRadius: 999,
          transition:
            "left 260ms cubic-bezier(.4,0,.2,1), width 260ms cubic-bezier(.4,0,.2,1)",
        }}
      />

      <TabButton
        ref={myRef}
        active={activeTab === "MY"}
        onClick={() => setActiveTab("MY")}
      >
        My Appointments
      </TabButton>

      <TabButton
        ref={availableRef}
        active={activeTab === "AVAILABLE"}
        onClick={() => setActiveTab("AVAILABLE")}
      >
        Available Appointments
      </TabButton>
    </div>
  );
}

const TabButton = forwardRef(function TabButton(
  { active, children, ...props },
  ref
) {
  return (
    <button
      ref={ref}
      {...props}
      style={{
        zIndex: 1,
        padding: "10px 18px",
        borderRadius: 999,
        border: "none",
        background: "transparent",
        fontWeight: 600,
        cursor: "pointer",
        color: active ? "#fff" : "#333",
      }}
    >
      {children}
    </button>
  );
});
