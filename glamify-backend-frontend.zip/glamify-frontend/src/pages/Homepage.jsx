import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllBeautyServices } from "../api/adminApi";
import logo from "../assets/glamify-logo.png";

export default function Homepage() {
  const navigate = useNavigate();
  const [services, setServices] = useState([]);

  useEffect(() => {
    getAllBeautyServices().then((data) => {
      setServices(data.filter(s => s.active).slice(0, 4));
    });
  }, []);

  return (
    <div style={{ padding: 24, maxWidth: 1100, margin: "0 auto" }}>
      
      {/* ================= LOGO (MATCH LOGIN / REGISTER) ================= */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          marginBottom: 28,
          cursor: "pointer"
        }}
        onClick={() => navigate("/")}
      >
        <div
          style={{
            background: "#3a3939",               // same black as login
            borderRadius: 16,                 // rounded rectangle
            padding: "15px 50px",             // matches login feel
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center"
          }}
        >
          <img
            src={logo}
            alt="Glamify"
            style={{ height: 60 }}
          />
        </div>
      </div>

      {/* ================= INTRO ================= */}
      <div
        className="card"
        style={{
          padding: 24,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: 24,
          marginBottom: 24
        }}
      >
        <div>
          <h2 style={{ marginBottom: 8 }}>
            Book trusted beauty professionals at your doorstep
          </h2>
          <p style={{ color: "#666", maxWidth: 520 }}>
            Discover verified professionals, transparent pricing, and
            hassle-free bookings — all in one place.
          </p>
        </div>

        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <button
            className="btn"
            style={{ borderRadius: 999, padding: "10px 60px" }}
            onClick={() => navigate("/login")}
          >
            Login
          </button>
        </div>
      </div>

      {/* ================= ROLES ================= */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
          gap: 16,
          marginBottom: 24
        }}
      >
        <RoleCard
          title="For Customers"
          icon="💁‍♀️"
          points={[
            "Browse beauty services",
            "Choose your professional",
            "Book at your convenience"
          ]}
          //action="Explore Services"
          //onClick={() => navigate("/services")}
        />

        <RoleCard
          title="For Professionals"
          icon="💼"
          points={[
            "Accept appointments",
            "Manage availability",
            "Grow your business"
          ]}
          //action="Join as Professional"
          //onClick={() => navigate("/professional/register")}
        />

        <RoleCard
          title="For Admins"
          icon="🛠️"
          points={[
            "Approve professionals",
            "Manage services",
            "Monitor platform activity"
          ]}
          //action="Admin Login"
          //onClick={() => navigate("/login")}
        />
      </div>

      {/* ================= POPULAR SERVICES (HARD CODED) ================= */}
      <div className="card" style={{ padding: 20, marginBottom: 24 }}>
        <h4 style={{ marginBottom: 12 }}>Popular Services</h4>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
            gap: 16
          }}
        >
          <div className="card" style={{ padding: 16 }}>
            <strong>Facial Cleanup</strong>
            <div style={{ fontSize: 13, color: "#666", margin: "6px 0" }}>
              Skincare
            </div>
            <div style={{ fontSize: 14 }}>
              60 min
            </div>
          </div>

          <div className="card" style={{ padding: 16 }}>
            <strong>Haircut & Styling</strong>
            <div style={{ fontSize: 13, color: "#666", margin: "6px 0" }}>
              Hair
            </div>
            <div style={{ fontSize: 14 }}>
              45 min
            </div>
          </div>

          <div className="card" style={{ padding: 16 }}>
            <strong>Bridal Makeup</strong>
            <div style={{ fontSize: 13, color: "#666", margin: "6px 0" }}>
              Makeup
            </div>
            <div style={{ fontSize: 14 }}>
              120 min
            </div>
          </div>

          <div className="card" style={{ padding: 16 }}>
            <strong>Manicure & Pedicure</strong>
            <div style={{ fontSize: 13, color: "#666", margin: "6px 0" }}>
              Nails
            </div>
            <div style={{ fontSize: 14 }}>
              90 min
            </div>
          </div>
        </div>
      </div>

      {/* ================= HOW IT WORKS ================= */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
          gap: 16,
          marginBottom: 24
        }}
      >
        <StepCard step="1" title="Choose a Service" text="Browse from a wide range of beauty services." />
        <StepCard step="2" title="Pick Time & Professional" text="Select a convenient slot and verified expert." />
        <StepCard step="3" title="Relax at Home" text="We come to you — no travel, no stress." />
      </div>

      {/* ================= STATS =================
      <div
        className="card"
        style={{
          padding: 20,
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
          gap: 16,
          marginBottom: 24
        }}
      >
        <Stat label="Active Users" value="100+" />
        <Stat label="Beauty Services" value="25+" />
        <Stat label="Daily Bookings" value="10+" />
        <Stat label="Verified Professionals" value="15+" />
      </div> */}

      {/* ================= FOOTER ================= */}
      <div style={{ textAlign: "center", color: "#000000", fontSize: 13 }}>
        <b>© {new Date().getFullYear()}Glamify. All rights reserved.</b>
      </div>
    </div>
  );
}

/* ================= SUB COMPONENTS ================= */

function RoleCard({ title, icon, points, action, onClick }) {
  return (
    <div className="card" style={{ padding: 20 }}>
      <h4 style={{ marginBottom: 8 }}>
        {icon} {title}
      </h4>

      <ul style={{ paddingLeft: 16, fontSize: 14, color: "#555" }}>
        {points.map((p) => (
          <li key={p}>{p}</li>
        ))}
      </ul>

      <button
        className="btn"
        style={{ marginTop: 12, borderRadius: 999, padding: "6px 16px" }}
        onClick={onClick}
      >
        {action}
      </button>
    </div>
  );
}

function StepCard({ step, title, text }) {
  return (
    <div className="card" style={{ padding: 20 }}>
      <strong style={{ fontSize: 18 }}>{step}</strong>
      <h4 style={{ margin: "6px 0" }}>{title}</h4>
      <p style={{ color: "#666", fontSize: 14 }}>{text}</p>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 13, color: "#777" }}>{label}</div>
      <div style={{ fontSize: 24, fontWeight: 600 }}>{value}</div>
    </div>
  );
}
