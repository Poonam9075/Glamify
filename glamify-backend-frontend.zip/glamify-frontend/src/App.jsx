import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider } from "./context/CartContext";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import Login from "./pages/auth/Login";
import CustomerDashboard from "./pages/customer/CustomerDashboard";
import AdminDashboard from "./pages/admin/AdminDashboard";
import ProfessionalTabs from "./pages/professional/ProfessionalTabs";
import Booking from "./pages/customer/Booking";
import BookingSuccess from "./pages/customer/BookingSuccess";
import CustomerTabs from "./pages/customer/CustomerTabs";
import BookingHistory from "./pages/customer/BookingHistory";
import Register from "./pages/auth/Register";
import Homepage from "./pages/Homepage";

export default function App() {
  return (
    <div className="app-background">
    <AuthProvider>
      <CartProvider>
        <BrowserRouter>
          {/* Global Navbar */}
          <Navbar />

          <Routes>
            {/* Public */}
            <Route path="/" element={<Homepage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* Customer */}
            <Route
              path="/customer"
              element={
                <ProtectedRoute allowedRoles={["CUSTOMER"]}>
                  <CustomerTabs />
                </ProtectedRoute>
              }
            />

            <Route
              path="/booking"
              element={
                <ProtectedRoute allowedRoles={["CUSTOMER"]}>
                  <Booking />
                </ProtectedRoute>
              }
            />

            <Route
              path="/booking/success"
              element={
                <ProtectedRoute allowedRoles={["CUSTOMER"]}>
                  <BookingSuccess />
                </ProtectedRoute>
              }
            />

            <Route
              path="/customer/bookings"
              element={
                <ProtectedRoute allowedRoles={["CUSTOMER"]}>
                  <BookingHistory />
                </ProtectedRoute>
              }
            />

            {/* Admin */}
            <Route
              path="/admin"
              element={
                <ProtectedRoute allowedRoles={["ADMIN"]}>
                  <AdminDashboard />
                </ProtectedRoute>
              }
            />

            {/* Professional (REDIRECT + TABS) */}
            <Route
              path="/professional"
              element={<Navigate to="/professional/dashboard" replace />}
            />

            <Route
              path="/professional/dashboard"
              element={
                <ProtectedRoute allowedRoles={["PROFESSIONAL"]}>
                  <ProfessionalTabs />
                </ProtectedRoute>
              }
            />
          </Routes>
        </BrowserRouter>
      </CartProvider>
    </AuthProvider>
    </div>
  );
}
