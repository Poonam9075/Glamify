import { useContext, useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { CartContext } from "../context/CartContext";

import logo from "../assets/glamify-logo.png";

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const { cart, clearCart } = useContext(CartContext);
  const navigate = useNavigate();

  // Hooks must always run
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  const handleLogout = () => {
    clearCart();
    logout();
    setOpen(false);
    navigate("/");
  };

  const handleHome = () => {
    navigate("/");
    // if (!user) navigate("/login");
    // if (user.role === "ADMIN") navigate("/admin");
    // else if (user.role === "PROFESSIONAL") navigate("/professional");
    // else navigate("/customer");
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () =>
      document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Safe conditional render AFTER hooks
  if (!user) return null;

  // Username logic (clean + safe)
  const fullName =
    user.fullName ||
    user.name ||
    user.customerName ||
    "Account";

  return (
    <div className="navbar">
      <div className="navbar-inner">
        {/* LEFT: LOGO */}
        <div
          className="navbar-left"
          onClick={handleHome}
          style={{ cursor: "pointer" }}
        >
          <img src={logo} alt="Glamify" />
        </div>

        {/* RIGHT */}
        <div
          className="navbar-right"
          style={{ display: "flex", alignItems: "center", gap: 16 }}
        >
          {/* ROLE (ADDED) */}
          <span className="navbar-role">
            {user.role}
          </span>

          {/* CART (Customer only) */}
          {user.role === "CUSTOMER" && (
            <span className="navbar-cart">
              🛒 {cart.length}
            </span>
          )}

          {/* SEPARATOR */}
          <span
            style={{
              height: 20,
              width: 1,
              background: "rgba(255,255,255,0.3)"
            }}
          />

          {/* ACCOUNT DROPDOWN */}
          <div
            ref={dropdownRef}
            style={{ position: "relative" }}
            onMouseDown={(e) => e.stopPropagation()}
          >
            <div
              onClick={() => setOpen(!open)}
              style={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 6,
                color: "#fff",
                fontWeight: 500
              }}
            >
              {fullName} ▾
            </div>

            {open && (
              <div
                style={{
                  position: "absolute",
                  right: 0,
                  top: "120%",
                  background: "#fff",
                  color: "#111",
                  borderRadius: 10,
                  boxShadow:
                    "0 10px 25px rgba(0,0,0,0.15)",
                  minWidth: 180,
                  overflow: "hidden",
                  zIndex: 1000
                }}
              >
                {/* {user.role === "CUSTOMER" && (
                  <div
                    onClick={() => {
                      navigate("/customer/bookings");
                      setOpen(false);
                    }}
                    style={menuItemStyle}
                  >
                    My Bookings
                  </div>
                )} */}

                <div
                  onClick={handleLogout}
                  style={{
                    ...menuItemStyle,
                    color: "#d93025",
                    fontWeight: 500
                  }}
                >
                  Logout
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const menuItemStyle = {
  padding: "12px 16px",
  cursor: "pointer",
  fontSize: 14,
  borderBottom: "1px solid #eee"
};
