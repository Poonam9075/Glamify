export default function CenterContainer({
  children,
  centerVertically = false
}) {
  return (
    <div
      style={{
        minHeight: centerVertically
          ? "100vh"
          : "calc(100vh - 40px)", // ✅ FIX: account for padding
        display: "flex",
        justifyContent: "center",
        alignItems: centerVertically ? "center" : "flex-start",
        paddingTop: centerVertically ? 0 : 40
      }}
    >
      {centerVertically ? (
        children
      ) : (
        <div style={{ maxWidth: 1100, width: "100%" }}>
          {children}
        </div>
      )}
    </div>
  );
}
