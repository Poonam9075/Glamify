import { useContext } from "react";
import { CartContext } from "../context/CartContext";

export default function ServiceCard({ service }) {
  const { addToCart } = useContext(CartContext);

  const hasDiscount = service.discount > 0;
  const discountedPrice = hasDiscount
    ? service.price - (service.price * service.discount) / 100
    : service.price;

  return (
    <div className="service-card">
      <h3 style={{ marginBottom: 6 }}>{service.name}</h3>

      <p style={{ fontSize: 13, color: "#777", marginBottom: 10 }}>
        {service.category} • {service.duration} mins
      </p>

      {/* PRICE SECTION */}
      <div style={{ marginBottom: 12 }}>
        {hasDiscount ? (
          <>
            <span
              style={{
                textDecoration: "line-through",
                color: "#999",
                marginRight: 8
              }}
            >
              ₹{service.price}
            </span>

            <span style={{ fontWeight: 600 }}>
              ₹{Math.round(discountedPrice)}
            </span>

            <span
              style={{
                marginLeft: 8,
                color: "green",
                fontSize: 12,
                fontWeight: 600
              }}
            >
              {service.discount}% OFF
            </span>
          </>
        ) : (
          <strong>₹{service.price}</strong>
        )}
      </div>

      <button className="btn" onClick={() => addToCart(service)}>
        Add
      </button>
    </div>
  );
}
