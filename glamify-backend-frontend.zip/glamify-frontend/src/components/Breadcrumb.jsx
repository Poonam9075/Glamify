import { useNavigate } from "react-router-dom";

export default function Breadcrumb({ items }) {
  const navigate = useNavigate();

  return (
    <div
  style={{
    width: "100%",
    marginBottom: 16,
    fontSize: 14,
    color: "#555",
    textAlign: "left"
  }}
>
      {items.map((item, index) => (
        <span key={index}>
          {item.path ? (
            <span
              onClick={() => navigate(item.path)}
              style={{
                cursor: "pointer",
                color: "#6e46ff",
                fontWeight: 500
              }}
            >
              {item.label}
            </span>
          ) : (
            <span style={{ fontWeight: 600 }}>
              {item.label}
            </span>
          )}

          {index < items.length - 1 && (
            <span style={{ margin: "0 8px" }}>/</span>
          )}
        </span>
      ))}
    </div>
  );
}
