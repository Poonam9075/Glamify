import { useState } from "react";
import logo from "../assets/glamify-logo.png";

export default function FakeRazorpay({
  amount,
  onSuccess,
  onClose
}) {
  const [loading, setLoading] = useState(false);
  const [method, setMethod] = useState("upi");

  const handlePay = () => {
    setLoading(true);

    setTimeout(() => {
      const fakePaymentId =
        "pay_" + Math.random().toString(36).slice(2, 12);

      onSuccess(fakePaymentId);
    }, 1800);
  };

  return (
    <div style={overlay}>
      <div style={modal}>
        {/* HEADER */}
        <div style={header}>
          <img src={logo} alt="Glamify" style={logoStyle} />
          <strong>Glamify Payments</strong>
        </div>

        {/* AMOUNT */}
        <div style={amountBox}>
          <div style={{ fontSize: 13, color: "#666" }}>
            Amount to Pay
          </div>
          <div style={{ fontSize: 22, fontWeight: 600 }}>
            ₹{amount}
          </div>
        </div>

        {/* PAYMENT METHODS */}
        <div style={{ marginBottom: 18 }}>
          <div style={methodTitle}>Choose payment method</div>

          <label style={methodRow}>
            <input
              type="radio"
              name="payment"
              checked={method === "upi"}
              onChange={() => setMethod("upi")}
              style={radio}
            />
            <span>UPI</span>
          </label>

          <label style={methodRow}>
            <input
              type="radio"
              name="payment"
              checked={method === "card"}
              onChange={() => setMethod("card")}
              style={radio}
            />
            <span>Credit / Debit Card</span>
          </label>

          <label style={methodRow}>
            <input
              type="radio"
              name="payment"
              checked={method === "netbanking"}
              onChange={() => setMethod("netbanking")}
              style={radio}
            />
            <span>Net Banking</span>
          </label>
        </div>

        {/* PAY BUTTON */}
        <button
          className="btn"
          onClick={handlePay}
          disabled={loading}
          style={{ marginBottom: 10 }}
        >
          {loading ? "Processing payment..." : `Pay ₹${amount}`}
        </button>

        {/* CANCEL */}
        <button
          onClick={onClose}
          disabled={loading}
          style={cancelBtn}
        >
          Cancel
        </button>

        {/* FOOTER */}
        <div style={footer}>
          Secured by <strong>Razorpay</strong>
        </div>
      </div>
    </div>
  );
}

/* ======================
   STYLES
   ====================== */

const overlay = {
  position: "fixed",
  inset: 0,
  background: "rgba(0,0,0,0.6)",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  zIndex: 9999
};

const modal = {
  width: 360,
  background: "#fff",
  borderRadius: 16,
  padding: 22,
  boxShadow: "0 20px 40px rgba(0,0,0,0.3)"
};

const header = {
  display: "flex",
  alignItems: "center",
  gap: 10,
  marginBottom: 16
};

const logoStyle = {
  height: 26
};

const amountBox = {
  padding: 14,
  background: "#f7f7f7",
  borderRadius: 10,
  textAlign: "center",
  marginBottom: 18
};

const methodTitle = {
  fontSize: 13,
  fontWeight: 600,
  marginBottom: 10
};

const methodRow = {
  display: "flex",
  alignItems: "center",
  gap: 12,
  padding: "10px 8px",
  borderRadius: 8,
  cursor: "pointer",
  fontSize: 14
};

const radio = {
  width: "auto",
  margin: 0
};

const cancelBtn = {
  width: "100%",
  background: "transparent",
  border: "none",
  color: "#555",
  cursor: "pointer",
  fontSize: 13
};

const footer = {
  textAlign: "center",
  fontSize: 11,
  color: "#777",
  marginTop: 10
};
