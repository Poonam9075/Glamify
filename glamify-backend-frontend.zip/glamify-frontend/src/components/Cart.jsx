import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { CartContext } from "../context/CartContext";

export default function Cart() {
  const { cart, removeFromCart } = useContext(CartContext);
  const navigate = useNavigate();

  // Price calculations
  const subtotal = cart.reduce((sum, s) => sum + s.price, 0);

  const discount = cart.reduce((sum, s) => {
    return s.discount > 0
      ? sum + (s.price * s.discount) / 100
      : sum;
  }, 0);

  const total = subtotal - discount;

  return (
    <div
      style={{
        position: "sticky",
        top: 100,
        alignSelf: "flex-start"
      }}
    >
      <div className="card">
        <h3 style={{ textAlign: "center", marginBottom: 16 }}>
          Your Cart
        </h3>

        {/* EMPTY CART */}
        {cart.length === 0 && (
          <p style={{ textAlign: "center", color: "#777" }}>
            Cart is empty
          </p>
        )}

        {/* CART ITEMS */}
        {cart.map((s) => {
          const hasDiscount = s.discount > 0;
          const finalPrice = hasDiscount
            ? s.price - (s.price * s.discount) / 100
            : s.price;

          return (
            <div
              key={s.id}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 12
              }}
            >
              <div>
                <div style={{ fontSize: 14 }}>{s.name}</div>

                {hasDiscount && (
                  <div
                    style={{
                      fontSize: 12,
                      textDecoration: "line-through",
                      color: "#999"
                    }}
                  >
                    ₹{s.price}
                  </div>
                )}
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8
                }}
              >
                <strong>₹{Math.round(finalPrice)}</strong>

                <button
                  onClick={() => removeFromCart(s.id)}
                  style={{
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    color: "red",
                    fontSize: 16
                  }}
                >
                  ✕
                </button>
              </div>
            </div>
          );
        })}

        {/* PRICE SUMMARY */}
        {cart.length > 0 && (
          <>
            <hr style={{ margin: "16px 0" }} />

            <div style={{ fontSize: 14, marginBottom: 6 }}>
              <span>Subtotal</span>
              <span style={{ float: "right" }}>
                ₹{Math.round(subtotal)}
              </span>
            </div>

            <div
              style={{
                fontSize: 14,
                marginBottom: 6,
                color: "green"
              }}
            >
              <span>Discount</span>
              <span style={{ float: "right" }}>
                -₹{Math.round(discount)}
              </span>
            </div>

            <hr />

            <div
              style={{
                fontSize: 16,
                fontWeight: 600,
                marginBottom: 16
              }}
            >
              <span>Total Payable</span>
              <span style={{ float: "right" }}>
                ₹{Math.round(total)}
              </span>
            </div>

            {/* PROCEED BUTTON */}
            <button
              className="btn"
              onClick={() => navigate("/booking")}
            >
              Proceed to Booking
            </button>
          </>
        )}
      </div>
    </div>
  );
}
