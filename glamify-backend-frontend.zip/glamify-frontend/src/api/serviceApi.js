import api from "./axios";

export const getAllServices = async () => {
  const res = await api.get("/api/customer/services"); // adjust endpoint if needed
  return res.data;
};
