import api from "./axios";

// Existing APIs (unchanged)
export const getPendingProfessionals = async () => {
  const res = await api.get("/api/admin/professionals/pending");
  return res.data;
};

export const approveProfessional = async (userId) => {
  const res = await api.put(
    `/api/admin/professionals/${userId}/approve`
  );
  return res.data;
};

export const getAllUsers = async () => {
  const res = await api.get("/api/admin/users");
  return res.data;
};

export const getAllBeautyServices = async () => {
  const res = await api.get("/api/admin/beauty-services");
  return res.data;
};

// 🔥 NEW — Activate / Deactivate user
export const toggleUserStatus = async (userId) => {
  const res = await api.put(
    `/api/admin/user/${userId}/toggle`
  );
  return res.data;
};

// Add new service
export const addBeautyService = async (payload) => {
  const res = await api.post("/api/admin/beauty-service", payload);
  return res.data;
};

// Update existing service
export const updateBeautyService = async (id, payload) => {
  const res = await api.put(
    `/api/admin/beauty-service/${id}`,
    payload
  );
  return res.data;
};

// Admin – all appointments / bookings
export const getAllAppointments = async () => {
  const res = await api.get("/api/admin/appointments");
  return res.data;
};
