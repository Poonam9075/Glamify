import api from "./axios";

export const loginUser = async ({ email, password }) => {
  const res = await api.post("/api/auth/login", {
    username: email,
    password
  });
  return res.data;
};

// CUSTOMER REGISTRATION
export const registerCustomer = async (data) => {
  const res = await api.post(
    "/api/auth/register/customer",
    data
  );
  return res.data;
};

// PROFESSIONAL REGISTRATION
export const registerProfessional = async (data) => {
  const res = await api.post(
    "/api/auth/register/professional",
    data
  );
  return res.data;
};
