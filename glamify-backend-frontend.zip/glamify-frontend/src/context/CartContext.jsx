import { createContext, useEffect, useState } from "react";

export const CartContext = createContext();

const CART_KEY = "glamify_cart";

export function CartProvider({ children }) {
  // 🔁 Load cart from localStorage on app start
  const [cart, setCart] = useState(() => {
    const stored = localStorage.getItem(CART_KEY);
    return stored ? JSON.parse(stored) : [];
  });

  // 💾 Persist cart on every change
  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart]);

  const addToCart = (service) => {
    setCart((prev) => {
      if (prev.find((s) => s.id === service.id)) return prev;
      return [...prev, service];
    });
  };

  const removeFromCart = (id) => {
    setCart((prev) => prev.filter((s) => s.id !== id));
  };

  const clearCart = () => {
    setCart([]);
    localStorage.removeItem(CART_KEY);
  };

  const totalAmount = cart.reduce((sum, s) => {
    const discounted =
      s.discount > 0 ? s.price - (s.price * s.discount) / 100 : s.price;
    return sum + discounted;
  }, 0);

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        totalAmount
      }}
    >
      {children}
    </CartContext.Provider>
  );
}
